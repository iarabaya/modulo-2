if(document.getElementById('senate-data')){
    createTableSenate();
}else if(document.getElementById('house-data')){
    createTableHouse();
}

function createTableSenate(){
    var tablaNueva = newTable(data.results[0].members);
    var tablaSenado = document.getElementById('senate-data');
    tablaSenado.innerHTML = tablaNueva;
}

function createTableHouse(){
    var tablaNueva = newTable(data.results[0].members);
    var tablaHouse = document.getElementById('house-data');
    tablaHouse.innerHTML = tablaNueva;
}


function newTable(membersArray){
    var tabla = '<thead class="thead-dark"><tr><th>Full Name</th><th>Party Afflication</th><th>State</th><th>Seniority</th><th>% of votes with Party</th></tr>';;
    tabla += '<tbody>'

    membersArray.forEach(function(members){
        tabla += '<tr>';

        var middle = members.middle_name ? members.middle_name : '';
        var completeName = '<a href="'+ members.url+ '">'+ members.first_name + ' '+ middle + ' ' + members.last_name +'</a>';

        tabla += '<td>'+ completeName +'</td>';
        tabla += '<td class="party">'+ members.party+'</td>';
        tabla += '<td class="state">'+ members.state+'</td>';
        tabla += '<td>'+ members.seniority+'</td>';
        tabla += '<td> %'+ members.votes_with_party_pct +'</td>';

        tabla += '</tr>';
    });

    tabla += '</tbody>';
    return tabla;
}
