var arrayData = data.results[0].members

var senateStatistics={
    "total_members":0,
    "num_of_democrats":0,
    "num_of_republicans":0,
    "num_of_independents":0,
    "democrats_average_with_party":0,
    "republicans_average_with_party":0,
    "least_engaged":0,
    "most_engaged":0,
    };

  var democratList = [];
  var republicanList = [];
  var independentList = [];

  //Funcion para llenar el objeto Statitics
 function insert(obj){
   senateStatistics.total_members = obj.length;

   democratList = obj.filter(member => member.party == 'D');
   republicanList = obj.filter(member => member.party == 'R');
   independentList = obj.filter(member => member.party == 'I');

   senateStatistics.num_of_democrats = democratList.length;
   senateStatistics.num_of_republicans = republicanList.length;
   senateStatistics.num_of_independents = independentList.length;


   console.log(senateStatistics.total_members + " cantidad de miembros y " + senateStatistics.num_of_democrats + " son democratas")
   console.log(senateStatistics.num_of_republicans + " son republicanos")
   console.log(senateStatistics.num_of_independents + " son independientes")

   senateStatistics.democrats_average_with_party = average(democratList,"votes_with_party_pct");
   senateStatistics.republicans_average_with_party = average(republicanList,"votes_with_party_pct");
  

   console.log(senateStatistics.democrats_average_with_party + " % promedio de votos por partido de democratas")
   console.log(senateStatistics.republicans_average_with_party + " % promedio de votos por partido de repubicanos")

 }

 insert(arrayData);


//FUNCIONES DE CALCULOS ESTADISTICOS
//Promedio
function average(obj,key){
  var avg = 0;
  avg = (obj.reduce(function(a,b){ return a + b[key];},0))/obj.length;
  return avg;
}

//Function for the ones who least vote with their party
//tengo que seleccionar un 10% del total
 function leastSth(obj,key){
   var porcentaje = 10;
   var least = [];
   var minimo = 0;
   
 }



