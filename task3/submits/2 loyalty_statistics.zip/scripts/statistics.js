var arrayData = data.results[0].members;

var statistics = {
  "total_members": 0,
  "num_of_democrats": 0,
  "num_of_republicans": 0,
  "num_of_independents": 0,
  "democrats_average_votes_with_party": 0,
  "republicans_average_votes_with_party": 0,
  "total_average_votes_with_party": 0,
  "least_engaged": 0,
  "most_engaged": 0,
  "least_loyal": 0,
  "most_loyal": 0
};

var democratList = [];
var republicanList = [];
var independentList = [];


//Funcion para llenar el objeto Statitics
function fillStatistics(obj) {

  //para no mostrar los delegates solo filtro a los representatives (que son los que votan)
  if (data.results[0].chamber === "House") {
    obj = obj.filter(member => member.title == 'Representative');
  }

  statistics.total_members = obj.length;

  democratList = obj.filter(member => member.party == 'D');
  republicanList = obj.filter(member => member.party == 'R');

  statistics.num_of_democrats = democratList.length;
  statistics.num_of_republicans = republicanList.length;

  console.log(statistics.total_members + " cantidad de miembros y " + statistics.num_of_democrats + " son democratas")
  console.log(statistics.num_of_republicans + " son republicanos")


  //Solo para la cámara que además tenga Independientes
  if (data.results[0].chamber == "Senate") {
    independentList = obj.filter(member => member.party == 'I');
    statistics.num_of_independents = independentList.length;
    console.log(statistics.num_of_independents + " son independientes");
  }

  statistics.democrats_average_votes_with_party = average(democratList, "votes_with_party_pct");
  statistics.republicans_average_votes_with_party = average(republicanList, "votes_with_party_pct");


  console.log(statistics.democrats_average_votes_with_party + " % promedio de votos por partido de democratas")
  console.log(statistics.republicans_average_votes_with_party + " % promedio de votos por partido de repubicanos")

  statistics.most_loyal = mostSth(obj, "votes_with_party_pct");
  statistics.least_loyal = leastSth(obj, "votes_with_party_pct");

  console.log("the most loyal");
  console.log(statistics.most_loyal);
  console.log("the least loyal");
  console.log(statistics.least_loyal);

  /*statistics.most_engaged = leastSth(obj, "missed_votes_pct");
  statistics.least_engaged = mostSth(obj, "missed_votes_pct");

  console.log(statistics.most_engaged);
  console.log(statistics.least_engaged);*/
  
}

fillStatistics(arrayData);



//FUNCIONES DE CALCULOS ESTADISTICOS

//Promedio
function average(obj, key) {
  var avg = 0;
  avg = (obj.reduce(function (a, b) {
    return a + b[key];
  }, 0)) / obj.length;
  return Math.round(avg);
}

//Function for the ones who least vote with their party
function leastSth(obj, key) {
  var limite = obj.length * 0.1;
  var least = [];
  var members = obj.sort(function (a, b) {
    return a[key] - b[key];
  })

  var i = 0;
  while (i < limite) {
    least.push(members[i]);
    i++;
  }
  //para agregar si el ultimo elemento del array tambien tiene otros con el mismo valor pero superan el porcentaje limite
  var ultimos = members.filter(member => member[key] == least[least.length - 1][key] && !least.includes(member));
  if (ultimos.length != 0) { //el IF me permite concatenar los arrays, el porcentaje pedido con el excedente
    least = least.concat(ultimos)
  }
  return least;
}

//Function for the ones who most vote with their party
function mostSth(obj, key) {
  var limite = obj.length * 0.1;
  var most = [];
  var members = obj.sort(function (a, b) {
    return b[key] - a[key];
  })


  var i = 0;
  while (i <= limite) {
    most.push(members[i]);
    i++;
  }

  var ultimos = members.filter(member => member[key] == most[most.length - 1][key] && !most.includes(member));
  if (ultimos.length != 0) {
    most = most.concat(ultimos)
  }
  return most;
}